package com.example.dualaudiorouter

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.util.Log
import androidx.annotation.Keep
import java.lang.reflect.Method

class DualAudioService : IDualAudioService.Stub {

    companion object {
        private const val TAG = "DualAudioService"
    }

    private var audioManager: AudioManager? = null

    constructor() {
        Log.i(TAG, "Default constructor called")
    }

    @Keep
    constructor(context: Context) {
        Log.i(TAG, "Context constructor called")
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        Log.i(TAG, "AudioManager obtained: $audioManager")
    }

    override fun destroy() {
        Log.i(TAG, "destroy() called")
        clearDualOutput()
        audioManager = null
        System.exit(0)
    }

    override fun setDualOutput(speakerType: Int, btType: Int) {
        Log.i(TAG, "setDualOutput called speakerType=$speakerType btType=$btType")
        val am = audioManager
        if (am == null) {
            Log.e(TAG, "AudioManager is null!")
            return
        }

        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        Log.i(TAG, "Found ${devices.size} output devices")
        for (d in devices) {
            Log.i(TAG, "  Device: type=${d.type} name=${d.productName} id=${d.id}")
        }

        val speaker = devices.firstOrNull { it.type == speakerType }
        val btDevice = devices.firstOrNull { it.type == btType }

        if (speaker == null) {
            Log.e(TAG, "Speaker device not found for type $speakerType")
            return
        }
        if (btDevice == null) {
            Log.e(TAG, "Bluetooth device not found for type $btType")
            return
        }

        Log.i(TAG, "Speaker: ${speaker.productName}, BT: ${btDevice.productName}")

        val strategy = findMediaStrategy()
        if (strategy == null) {
            Log.e(TAG, "Media strategy not found")
            return
        }
        Log.i(TAG, "Media strategy found: $strategy")

        try {
            val attrClass = Class.forName("android.media.AudioDeviceAttributes")
            val ctor = attrClass.getConstructor(AudioDeviceInfo::class.java)
            val speakerAttr = ctor.newInstance(speaker)
            val btAttr = ctor.newInstance(btDevice)
            val list = listOf(speakerAttr, btAttr)
            Log.i(TAG, "Created AudioDeviceAttributes list size=${list.size}")

            invokeSetPreferredDevicesForStrategy(am, strategy, list)
            Log.i(TAG, "setPreferredDevicesForStrategy call finished")
        } catch (e: Exception) {
            Log.e(TAG, "Error in setDualOutput", e)
        }
    }

    override fun clearDualOutput() {
        Log.i(TAG, "clearDualOutput called")
        val am = audioManager ?: return
        val strategy = findMediaStrategy() ?: return
        invokeRemovePreferredDeviceForStrategy(am, strategy)
    }

    override fun isDualActive(): Boolean {
        val am = audioManager ?: return false
        val strategy = findMediaStrategy() ?: return false
        val preferred = invokeGetPreferredDevicesForStrategy(am, strategy)
        val active = preferred != null && preferred.size > 1
        Log.i(TAG, "isDualActive = $active (preferred size=${preferred?.size})")
        return active
    }

    private fun findMediaStrategy(): Any? {
        return try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val getStrategies = strategyClass.getMethod("getAudioProductStrategies")
            @Suppress("UNCHECKED_CAST")
            val strategies = getStrategies.invoke(null) as? List<Any> ?: return null
            Log.i(TAG, "Found ${strategies.size} AudioProductStrategies")

            val mediaAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()

            val supportsMethod = try {
                strategyClass.getMethod("supportsAudioAttributes", AudioAttributes::class.java)
            } catch (_: NoSuchMethodException) {
                null
            }

            if (supportsMethod != null) {
                for (strategy in strategies) {
                    val supports = supportsMethod.invoke(strategy, mediaAttrs) as? Boolean
                    if (supports == true) {
                        Log.i(TAG, "Found strategy that supports MEDIA")
                        return strategy
                    }
                }
            }
            strategies.firstOrNull()
        } catch (e: Exception) {
            Log.e(TAG, "findMediaStrategy failed", e)
            null
        }
    }

    private fun invokeSetPreferredDevicesForStrategy(am: AudioManager, strategy: Any, devices: List<Any>) {
        try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = AudioManager::class.java.getMethod(
                "setPreferredDevicesForStrategy",
                strategyClass,
                java.util.List::class.java
            )
            Log.i(TAG, "Calling setPreferredDevicesForStrategy...")
            method.invoke(am, strategy, devices)
            Log.i(TAG, "setPreferredDevicesForStrategy SUCCESS")
        } catch (e: Exception) {
            Log.e(TAG, "setPreferredDevicesForStrategy FAILED", e)
            // Try alternative method names used by some OEMs
            tryAlternativeSet(am, strategy, devices)
        }
    }

    private fun tryAlternativeSet(am: AudioManager, strategy: Any, devices: List<Any>) {
        val names = listOf(
            "setPreferredDeviceForStrategy",
            "setDevicesForStrategy",
            "setPreferredDevices"
        )
        for (name in names) {
            try {
                val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
                val method = AudioManager::class.java.getMethod(name, strategyClass, java.util.List::class.java)
                method.invoke(am, strategy, devices)
                Log.i(TAG, "Alternative method $name SUCCESS")
                return
            } catch (e: Exception) {
                Log.w(TAG, "Alternative $name failed: ${e.message}")
            }
        }
    }

    private fun invokeRemovePreferredDeviceForStrategy(am: AudioManager, strategy: Any) {
        try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = try {
                AudioManager::class.java.getMethod("removePreferredDeviceForStrategy", strategyClass)
            } catch (_: NoSuchMethodException) {
                AudioManager::class.java.getMethod("clearPreferredDevicesForStrategy", strategyClass)
            }
            method.invoke(am, strategy)
            Log.i(TAG, "clear/remove preferred devices SUCCESS")
        } catch (e: Exception) {
            Log.e(TAG, "clear preferred devices FAILED", e)
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun invokeGetPreferredDevicesForStrategy(am: AudioManager, strategy: Any): List<Any>? {
        return try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = AudioManager::class.java.getMethod("getPreferredDevicesForStrategy", strategyClass)
            method.invoke(am, strategy) as? List<Any>
        } catch (e: Exception) {
            Log.e(TAG, "getPreferredDevicesForStrategy FAILED", e)
            null
        }
    }
}
