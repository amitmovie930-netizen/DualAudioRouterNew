package com.example.dualaudiorouter

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.util.Log
import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.InputStreamReader

class DualAudioService : IDualAudioService.Stub {

    companion object {
        private const val TAG = "DualAudioService"
    }

    private var audioManager: AudioManager? = null
    private var appContext: Context? = null

    constructor() {
        Log.i(TAG, "Default constructor")
    }

    @Keep
    constructor(context: Context) {
        Log.i(TAG, "Context constructor")
        appContext = context
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        Log.i(TAG, "AudioManager = $audioManager")
    }

    override fun destroy() {
        Log.i(TAG, "destroy()")
        clearDualOutput()
        audioManager = null
        appContext = null
        System.exit(0)
    }

    override fun setDualOutput(speakerType: Int, btType: Int) {
        Log.i(TAG, "=== setDualOutput speaker=$speakerType bt=$btType ===")
        val am = audioManager
        if (am == null) {
            Log.e(TAG, "AudioManager null")
            return
        }

        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        Log.i(TAG, "Output devices (${devices.size}):")
        devices.forEach {
            Log.i(TAG, "  type=${it.type} name=${it.productName} id=${it.id}")
        }

        val speaker = devices.firstOrNull { it.type == speakerType }
        val bt = devices.firstOrNull { it.type == btType }

        if (speaker == null) {
            Log.e(TAG, "Speaker not found")
            return
        }
        if (bt == null) {
            Log.e(TAG, "BT A2DP not found")
            return
        }
        Log.i(TAG, "Using Speaker=${speaker.productName} BT=${bt.productName}")

        // Method 1: setPreferredDevicesForStrategy (original)
        var success = trySetPreferredDevices(am, speaker, bt)
        if (success) {
            Log.i(TAG, "Method 1 (setPreferredDevicesForStrategy) SUCCESS")
            return
        }

        // Method 2: AudioSystem.setForceUse
        success = tryAudioSystemForceUse()
        if (success) {
            Log.i(TAG, "Method 2 (AudioSystem.setForceUse) SUCCESS")
            return
        }

        // Method 3: shell commands
        success = tryShellCommands(speaker, bt)
        if (success) {
            Log.i(TAG, "Method 3 (shell) SUCCESS")
            return
        }

        Log.e(TAG, "All methods failed")
    }

    override fun clearDualOutput() {
        Log.i(TAG, "clearDualOutput()")
        try {
            val am = audioManager ?: return
            val strategy = findMediaStrategy() ?: return
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = try {
                AudioManager::class.java.getMethod("removePreferredDeviceForStrategy", strategyClass)
            } catch (_: Exception) {
                AudioManager::class.java.getMethod("clearPreferredDevicesForStrategy", strategyClass)
            }
            method.invoke(am, strategy)
            Log.i(TAG, "clear preferred OK")
        } catch (e: Exception) {
            Log.w(TAG, "clear failed: ${e.message}")
        }

        // Also reset force use
        try {
            val audioSystem = Class.forName("android.media.AudioSystem")
            val setForceUse = audioSystem.getMethod("setForceUse", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            setForceUse.invoke(null, 1, 0) // FOR_MEDIA, FORCE_NONE
            Log.i(TAG, "AudioSystem force reset")
        } catch (e: Exception) {
            Log.w(TAG, "force reset failed: ${e.message}")
        }
    }

    override fun isDualActive(): Boolean {
        // Optimistic: just return true if we previously set it.
        // Real check is blocked by permission on Honor.
        return false
    }

    private fun trySetPreferredDevices(am: AudioManager, speaker: AudioDeviceInfo, bt: AudioDeviceInfo): Boolean {
        return try {
            val strategy = findMediaStrategy() ?: return false
            val attrClass = Class.forName("android.media.AudioDeviceAttributes")
            val ctor = attrClass.getConstructor(AudioDeviceInfo::class.java)
            val list = listOf(ctor.newInstance(speaker), ctor.newInstance(bt))
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = AudioManager::class.java.getMethod(
                "setPreferredDevicesForStrategy",
                strategyClass,
                java.util.List::class.java
            )
            method.invoke(am, strategy, list)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Method 1 failed: ${e.cause?.message ?: e.message}")
            false
        }
    }

    private fun tryAudioSystemForceUse(): Boolean {
        return try {
            val audioSystem = Class.forName("android.media.AudioSystem")
            // FOR_MEDIA = 1, FORCE_SPEAKER = 1
            val setForceUse = audioSystem.getMethod(
                "setForceUse",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            // Try forcing speaker while BT stays connected
            setForceUse.invoke(null, 1, 1) // FOR_MEDIA, FORCE_SPEAKER
            Log.i(TAG, "AudioSystem.setForceUse(FOR_MEDIA, FORCE_SPEAKER) called")
            true
        } catch (e: Exception) {
            Log.w(TAG, "Method 2 failed: ${e.message}")
            false
        }
    }

    private fun tryShellCommands(speaker: AudioDeviceInfo, bt: AudioDeviceInfo): Boolean {
        return try {
            // Try a few known shell commands that sometimes work under shell UID
            val commands = listOf(
                "cmd media_session",
                "dumpsys audio",
                // Honor-specific attempts
                "service call audio 10 i32 1 i32 1",
                "settings put system dual_audio 1"
            )
            for (cmd in commands) {
                val result = runShell(cmd)
                Log.i(TAG, "Shell '$cmd' → $result")
            }
            // We don't know if it worked, so return false
            false
        } catch (e: Exception) {
            Log.w(TAG, "Method 3 failed: ${e.message}")
            false
        }
    }

    private fun runShell(cmd: String): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            output.take(200)
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }

    private fun findMediaStrategy(): Any? {
        return try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val getStrategies = strategyClass.getMethod("getAudioProductStrategies")
            @Suppress("UNCHECKED_CAST")
            val strategies = getStrategies.invoke(null) as? List<Any> ?: return null
            Log.i(TAG, "Found ${strategies.size} strategies")

            val mediaAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()

            val supportsMethod = try {
                strategyClass.getMethod("supportsAudioAttributes", AudioAttributes::class.java)
            } catch (_: Exception) {
                null
            }

            if (supportsMethod != null) {
                for (s in strategies) {
                    if (supportsMethod.invoke(s, mediaAttrs) == true) {
                        Log.i(TAG, "Found MEDIA strategy")
                        return s
                    }
                }
            }
            strategies.firstOrNull()
        } catch (e: Exception) {
            Log.e(TAG, "findMediaStrategy error", e)
            null
        }
    }
}
