# DualAudioRouter

Routes media audio to **internal speaker + Bluetooth A2DP** at the same time (Samsung Dual Audio style).

Uses Shizuku (shell UID) to call the hidden API `AudioManager.setPreferredDevicesForStrategy()`.

## Important limitation on Honor / MagicOS

On Honor Pad 8 (and most Honor devices) the system **denies** `MODIFY_AUDIO_ROUTING` even to the shell UID provided by Shizuku.

Result:
- Method 1 (real dual routing) fails with “Missing MODIFY_AUDIO_ROUTING permission”
- Fallback only forces the speaker → you hear only one output

**True simultaneous speaker + Bluetooth is not possible without root on this tablet.**

The app now reports the real status honestly instead of pretending dual mode is active.

## Requirements

- Android 12+ (API 31)
- Shizuku v13+
- A paired Bluetooth A2DP device

## Build

```bash
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Usage

1. Start Shizuku
2. Install & open the app → grant Shizuku permission
3. Pair a Bluetooth speaker
4. Toggle Dual Audio ON
5. Play media

If only one speaker works, check logcat for `DualAudioService` – you will see the permission denial.
