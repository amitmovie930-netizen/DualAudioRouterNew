package com.example.dualaudiorouter

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.util.Log
import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Shizuku User Service (runs as shell UID 2000).
 *
 * True dual output (speaker + Bluetooth A2DP at the same time) requires
 * android.permission.MODIFY_AUDIO_ROUTING.
 *
 * On Honor / MagicOS this permission is denied even to shell UID.
 * Method 1 therefore fails and only single-output fallbacks are available.
 */
class DualAudioService : IDualAudioService.Stub {

    companion object {
        private const val TAG = "DualAudioService"

        // Shared across the process so isDualActive() is honest
        @Volatile
        private var dualReallyActive = false

        @Volatile
        private var lastStatus = "Idle"
    }

    private var audioManager: AudioManager? = null
    private var appContext: Context? = null

    constructor() {
        Log.i(TAG, "Default constructor")
    }

    @Keep
    constructor(context: Context) {
        Log.i(TAG, "Context constructor")
        appContext = context
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        Log.i(TAG, "AudioManager = $audioManager")
    }

    override fun destroy() {
        Log.i(TAG, "destroy()")
        clearDualOutput()
        audioManager = null
        appContext = null
        System.exit(0)
    }

    override fun setDualOutput(speakerType: Int, btType: Int) {
        Log.i(TAG, "=== setDualOutput speaker=$speakerType bt=$btType ===")
        dualReallyActive = false
        lastStatus = "Trying..."

        val am = audioManager
        if (am == null) {
            lastStatus = "AudioManager null"
            Log.e(TAG, lastStatus)
            return
        }

        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        Log.i(TAG, "Output devices (${devices.size}):")
        devices.forEach {
            Log.i(TAG, "  type=${it.type} name=${it.productName} id=${it.id}")
        }

        val speaker = devices.firstOrNull { it.type == speakerType }
        val bt = devices.firstOrNull { it.type == btType }

        if (speaker == null) {
            lastStatus = "Speaker device not found"
            Log.e(TAG, lastStatus)
            return
        }
        if (bt == null) {
            lastStatus = "Bluetooth A2DP not found – pair a speaker first"
            Log.e(TAG, lastStatus)
            return
        }
        Log.i(TAG, "Using Speaker=${speaker.productName} BT=${bt.productName}")

        // ---------- Method 1: real dual routing (needs MODIFY_AUDIO_ROUTING) ----------
        if (trySetPreferredDevices(am, speaker, bt)) {
            dualReallyActive = true
            lastStatus = "Dual output ACTIVE (Method 1)"
            Log.i(TAG, lastStatus)
            return
        }

        // ---------- Method 2: force speaker only (does NOT keep BT) ----------
        if (tryAudioSystemForceUse()) {
            // This succeeds on Honor but only forces speaker – BT is muted for media
            dualReallyActive = false
            lastStatus = "Honor blocked dual routing. Only speaker forced (BT silent)."
            Log.w(TAG, lastStatus)
            return
        }

        // ---------- Method 3: shell experiments ----------
        tryShellCommands()
        dualReallyActive = false
        lastStatus = "All methods failed – Honor blocks MODIFY_AUDIO_ROUTING"
        Log.e(TAG, lastStatus)
    }

    override fun clearDualOutput() {
        Log.i(TAG, "clearDualOutput()")
        dualReallyActive = false
        lastStatus = "Cleared"

        try {
            val am = audioManager ?: return
            val strategy = findMediaStrategy() ?: return
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = try {
                AudioManager::class.java.getMethod("removePreferredDeviceForStrategy", strategyClass)
            } catch (_: Exception) {
                AudioManager::class.java.getMethod("clearPreferredDevicesForStrategy", strategyClass)
            }
            method.invoke(am, strategy)
            Log.i(TAG, "clear preferred OK")
        } catch (e: Exception) {
            Log.w(TAG, "clear preferred failed: ${e.message}")
        }

        // Reset force-use
        try {
            val audioSystem = Class.forName("android.media.AudioSystem")
            val setForceUse = audioSystem.getMethod(
                "setForceUse",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            // FOR_MEDIA = 1, FORCE_NONE = 0
            setForceUse.invoke(null, 1, 0)
            Log.i(TAG, "AudioSystem force reset to NONE")
        } catch (e: Exception) {
            Log.w(TAG, "force reset failed: ${e.message}")
        }
    }

    override fun isDualActive(): Boolean {
        return dualReallyActive
    }

    // Optional status string for the UI (we keep the AIDL simple for now)
    fun getLastStatus(): String = lastStatus

    // -------------------------------------------------------------------------
    // Method 1 – the only real dual-output path
    // -------------------------------------------------------------------------
    private fun trySetPreferredDevices(
        am: AudioManager,
        speaker: AudioDeviceInfo,
        bt: AudioDeviceInfo
    ): Boolean {
        return try {
            val strategy = findMediaStrategy() ?: return false
            val attrClass = Class.forName("android.media.AudioDeviceAttributes")
            val ctor = attrClass.getConstructor(AudioDeviceInfo::class.java)
            val list = listOf(ctor.newInstance(speaker), ctor.newInstance(bt))
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = AudioManager::class.java.getMethod(
                "setPreferredDevicesForStrategy",
                strategyClass,
                java.util.List::class.java
            )
            method.invoke(am, strategy, list)
            true
        } catch (e: Exception) {
            val msg = e.cause?.message ?: e.message ?: "unknown"
            Log.w(TAG, "Method 1 failed: $msg")
            false
        }
    }

    // -------------------------------------------------------------------------
    // Method 2 – only forces speaker (BT media is silenced)
    // -------------------------------------------------------------------------
    private fun tryAudioSystemForceUse(): Boolean {
        return try {
            val audioSystem = Class.forName("android.media.AudioSystem")
            val setForceUse = audioSystem.getMethod(
                "setForceUse",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            // FOR_MEDIA = 1, FORCE_SPEAKER = 1
            setForceUse.invoke(null, 1, 1)
            Log.i(TAG, "AudioSystem.setForceUse(FOR_MEDIA, FORCE_SPEAKER) called")
            true
        } catch (e: Exception) {
            Log.w(TAG, "Method 2 failed: ${e.message}")
            false
        }
    }

    // -------------------------------------------------------------------------
    // Method 3 – exploratory shell commands (rarely help on Honor)
    // -------------------------------------------------------------------------
    private fun tryShellCommands() {
        val commands = listOf(
            "settings put system dual_audio 1",
            "settings put global dual_audio 1",
            "cmd audio",
            "dumpsys audio | head -c 300"
        )
        for (cmd in commands) {
            val result = runShell(cmd)
            Log.i(TAG, "Shell '$cmd' → $result")
        }
    }

    private fun runShell(cmd: String): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            output.take(200).replace("\n", " ")
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }

    // -------------------------------------------------------------------------
    // Discover MEDIA strategy
    // -------------------------------------------------------------------------
    private fun findMediaStrategy(): Any? {
        return try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val getStrategies = strategyClass.getMethod("getAudioProductStrategies")
            @Suppress("UNCHECKED_CAST")
            val strategies = getStrategies.invoke(null) as? List<Any> ?: return null
            Log.i(TAG, "Found ${strategies.size} strategies")

            val mediaAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()

            val supportsMethod = try {
                strategyClass.getMethod("supportsAudioAttributes", AudioAttributes::class.java)
            } catch (_: Exception) {
                null
            }

            if (supportsMethod != null) {
                for (s in strategies) {
                    if (supportsMethod.invoke(s, mediaAttrs) == true) {
                        Log.i(TAG, "Found MEDIA strategy")
                        return s
                    }
                }
            }
            strategies.firstOrNull()
        } catch (e: Exception) {
            Log.e(TAG, "findMediaStrategy error", e)
            null
        }
    }
}
