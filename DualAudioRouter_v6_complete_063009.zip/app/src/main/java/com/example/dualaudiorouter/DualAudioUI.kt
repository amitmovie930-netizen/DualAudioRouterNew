package com.example.dualaudiorouter

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DualAudioUI(
    dualActive: Boolean,
    serviceConnected: Boolean,
    shizukuPermissionGranted: Boolean,
    onToggle: (Boolean) -> Unit,
    onRefreshState: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Dual Audio Router",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Status cards
        StatusCard("Shizuku permission", if (shizukuPermissionGranted) "Granted" else "Not granted")
        StatusCard("User service", if (serviceConnected) "Connected" else "Disconnected")
        StatusCard(
            "Dual output",
            if (dualActive) "ACTIVE (both speakers)" else "Inactive / blocked"
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Main toggle
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Dual Audio", fontSize = 18.sp)
            Switch(
                checked = dualActive,
                onCheckedChange = { enabled ->
                    onToggle(enabled)
                },
                enabled = serviceConnected && shizukuPermissionGranted
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Important warning for Honor
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.errorContainer
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "Honor / MagicOS limitation",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "This tablet blocks the system permission MODIFY_AUDIO_ROUTING even when running under Shizuku (shell).\n\n" +
                    "Therefore true simultaneous speaker + Bluetooth is not possible without root.\n\n" +
                    "When you toggle ON you will usually hear only the internal speakers (or only Bluetooth). " +
                    "This is expected behaviour on Honor Pad 8.",
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            "How to test:\n" +
            "1. Pair a Bluetooth speaker\n" +
            "2. Start Shizuku\n" +
            "3. Open this app and grant permission\n" +
            "4. Toggle Dual Audio ON\n" +
            "5. Play YouTube / music\n\n" +
            "If only one output works → the permission is blocked (normal on this device).",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StatusCard(title: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title)
            Text(value, fontWeight = FontWeight.Medium)
        }
    }
}
